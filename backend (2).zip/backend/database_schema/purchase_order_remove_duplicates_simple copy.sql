-- =====================================================
-- REMOVE DUPLICATE INDEXES - SAFE VERSION
-- =====================================================
-- IMPORTANT: Run purchase_order_check_duplicates.sql FIRST
-- This will only drop indexes that are TRUE duplicates
-- =====================================================

-- Check: Are there TWO different indexes on purchase_header_id?
-- One used by FK, one manual duplicate?
SET @has_fk_index = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND COLUMN_NAME = 'purchase_header_id'
    AND INDEX_NAME IN (
        SELECT CONSTRAINT_NAME 
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'tbl_purchase_order_dtl'
        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
    )
);

SET @has_manual_index = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND COLUMN_NAME = 'purchase_header_id'
    AND INDEX_NAME = 'idx_po_dtl_header'
    AND INDEX_NAME NOT IN (
        SELECT CONSTRAINT_NAME 
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'tbl_purchase_order_dtl'
        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
    )
);

-- Only drop if BOTH exist (meaning there's a duplicate)
SET @sql_drop = IF(@has_fk_index > 0 AND @has_manual_index > 0,
    'ALTER TABLE `tbl_purchase_order_dtl` DROP INDEX `idx_po_dtl_header`',
    'SELECT "No duplicate - idx_po_dtl_header is the FK index or does not exist" AS message'
);

PREPARE stmt FROM @sql_drop;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Same for supplier_id
SET @has_fk_supplier = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND COLUMN_NAME = 'supplier_id'
    AND INDEX_NAME IN (
        SELECT CONSTRAINT_NAME 
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'tbl_purchase_order_header'
        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
    )
);

SET @has_manual_supplier = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND COLUMN_NAME = 'supplier_id'
    AND INDEX_NAME = 'idx_po_supplier'
    AND INDEX_NAME NOT IN (
        SELECT CONSTRAINT_NAME 
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'tbl_purchase_order_header'
        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
    )
);

SET @sql_drop_supplier = IF(@has_fk_supplier > 0 AND @has_manual_supplier > 0,
    'ALTER TABLE `tbl_purchase_order_header` DROP INDEX `idx_po_supplier`',
    'SELECT "No duplicate - idx_po_supplier is the FK index or does not exist" AS message'
);

PREPARE stmt_supplier FROM @sql_drop_supplier;
EXECUTE stmt_supplier;
DEALLOCATE PREPARE stmt_supplier;

-- RESULT:
-- If you see "No duplicate" = Good! Your FK is using that index name, no problem
-- If index was dropped = There was a duplicate, now fixed ✅

