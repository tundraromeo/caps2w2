-- =====================================================
-- PURCHASE ORDER SYSTEM - Database Schema
-- =====================================================
-- Based on actual database structure from enguio2 database
-- Adjusted to match existing table structures and add proper foreign keys
-- =====================================================

-- NOTE: tbl_supplier already exists with the following structure:
-- supplier_id, supplier_name, supplier_address, supplier_contact, supplier_email,
-- order_level, primary_phone, primary_email, contact_person, contact_title,
-- payment_terms, lead_time_days, credit_rating, notes, status, created_at, updated_at

-- NOTE: tbl_product already exists with the following structure:
-- product_id, product_name, category_id, barcode, description, prescription, bulk,
-- product_type, expiration, brand_id, supplier_id, location_id, batch_id, status,
-- default_unit, allow_multi_unit, stock_status, date_added, created_at

-- 3. PURCHASE ORDER HEADER TABLE
-- =====================================================
-- One P.O. Header links to ONE supplier (via supplier_id FK)
-- NOTE: Table already exists, this shows the structure and required modifications
-- Current structure: purchase_header_id, po_number, date, expected_delivery_date, 
-- time, supplier_id, total_amount, created_by, status, notes

-- ALTER TABLE statement to add foreign key if it doesn't exist:
SET @fk_supplier_check = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND CONSTRAINT_NAME = 'fk_po_header_supplier'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_supplier = IF(@fk_supplier_check = 0,
    'ALTER TABLE `tbl_purchase_order_header` ADD CONSTRAINT `fk_po_header_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `tbl_supplier` (`supplier_id`) ON DELETE RESTRICT ON UPDATE CASCADE',
    'SELECT "Foreign key fk_po_header_supplier already exists" AS message'
);

PREPARE stmt_supplier FROM @sql_supplier;
EXECUTE stmt_supplier;
DEALLOCATE PREPARE stmt_supplier;

-- 4. PURCHASE ORDER DETAIL TABLE
-- =====================================================
-- Multiple products (items) per P.O. Header
-- Each detail links to ONE product (via product_id FK)
-- NOTE: Table already exists but MISSING product_id column and FK to tbl_product
-- Current structure: purchase_dtl_id, purchase_header_id, product_name, quantity,
-- unit_type, received_qty, missing_qty, item_status

-- STEP 1: Add product_id column to tbl_purchase_order_dtl
ALTER TABLE `tbl_purchase_order_dtl`
ADD COLUMN `product_id` INT(11) NULL AFTER `purchase_header_id`;

-- STEP 2: Populate product_id from product_name (matching existing data)
UPDATE `tbl_purchase_order_dtl` pod
LEFT JOIN `tbl_product` p ON p.product_name = pod.product_name
SET pod.product_id = p.product_id
WHERE pod.product_id IS NULL AND p.product_id IS NOT NULL;

-- STEP 3: Make product_id NOT NULL after population (optional, can keep NULL for historical data)
-- ALTER TABLE `tbl_purchase_order_dtl` 
-- MODIFY COLUMN `product_id` INT(11) NOT NULL;

-- STEP 4: Add Foreign Key: Purchase Order Detail -> Product
-- Check if constraint already exists first
SET @fk_product_check = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_product'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_product = IF(@fk_product_check = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD CONSTRAINT `fk_po_dtl_product` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`product_id`) ON DELETE RESTRICT ON UPDATE CASCADE',
    'SELECT "Foreign key fk_po_dtl_product already exists" AS message'
);

PREPARE stmt_product FROM @sql_product;
EXECUTE stmt_product;
DEALLOCATE PREPARE stmt_product;

-- STEP 5: Verify existing FK for header (should already exist as fk_po_dtl_header)
-- Check if it exists first to avoid errors
SET @fk_header_check = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_header'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

-- If not exists, add it:
SET @sql_fk_hdr = IF(@fk_header_check = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD CONSTRAINT `fk_po_dtl_header` FOREIGN KEY (`purchase_header_id`) REFERENCES `tbl_purchase_order_header` (`purchase_header_id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT "Foreign key fk_po_dtl_header already exists" AS message'
);

PREPARE stmt_fk_hdr FROM @sql_fk_hdr;
EXECUTE stmt_fk_hdr;
DEALLOCATE PREPARE stmt_fk_hdr;

-- =====================================================
-- RELATIONSHIPS SUMMARY
-- =====================================================
-- 1. tbl_supplier (1) <----> (N) tbl_purchase_order_header
--    - One supplier can have many purchase orders
--    - Each purchase order belongs to ONE supplier
--    - FK: tbl_purchase_order_header.supplier_id -> tbl_supplier.supplier_id
--
-- 2. tbl_purchase_order_header (1) <----> (N) tbl_purchase_order_dtl
--    - One purchase order header can have many detail items
--    - Each detail item belongs to ONE purchase order header
--    - FK: tbl_purchase_order_dtl.purchase_header_id -> tbl_purchase_order_header.purchase_header_id
--
-- 3. tbl_product (1) <----> (N) tbl_purchase_order_dtl
--    - One product can appear in many purchase order details
--    - Each purchase order detail links to ONE product
--    - FK: tbl_purchase_order_dtl.product_id -> tbl_product.product_id
--
-- =====================================================
-- DATA INTEGRITY CONSTRAINTS
-- =====================================================
-- - ON DELETE RESTRICT: Prevents deletion of supplier/product if referenced
-- - ON DELETE CASCADE: Deletes detail items if header is deleted
-- - ON UPDATE CASCADE: Updates FK values if parent PK changes
--
-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================
-- All foreign keys are automatically indexed
-- Additional indexes added for common query patterns

