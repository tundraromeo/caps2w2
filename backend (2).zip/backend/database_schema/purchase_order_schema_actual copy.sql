-- =====================================================
-- PURCHASE ORDER SYSTEM - Schema Based on Actual Database
-- =====================================================
-- Based on enguio2 database structure
-- Adds missing product_id and foreign key relationships
-- =====================================================

-- =====================================================
-- EXISTING TABLE STRUCTURES (for reference)
-- =====================================================

-- tbl_supplier (already exists)
-- PK: supplier_id
-- Fields: supplier_id, supplier_name, supplier_address, supplier_contact, 
--         supplier_email, order_level, primary_phone, primary_email, 
--         contact_person, contact_title, payment_terms, lead_time_days,
--         credit_rating, notes, status, created_at, updated_at

-- tbl_product (already exists)  
-- PK: product_id
-- Fields: product_id, product_name, category_id, barcode, description,
--         prescription, bulk, product_type, expiration, brand_id,
--         supplier_id, location_id, batch_id, status, default_unit,
--         allow_multi_unit, stock_status, date_added, created_at

-- tbl_purchase_order_header (already exists)
-- PK: purchase_header_id
-- Fields: purchase_header_id, po_number, date, expected_delivery_date,
--         time, supplier_id, total_amount, created_by, status, notes
-- FK: supplier_id -> tbl_supplier.supplier_id (index exists: fk_po_header_supplier)

-- tbl_purchase_order_dtl (already exists - NEEDS MODIFICATION)
-- PK: purchase_dtl_id
-- Fields: purchase_dtl_id, purchase_header_id, product_name, quantity,
--         unit_type, received_qty, missing_qty, item_status
-- MISSING: product_id column and FK to tbl_product
-- FK: purchase_header_id -> tbl_purchase_order_header.purchase_header_id (index exists: fk_po_dtl_header)

-- =====================================================
-- MIGRATION STEPS
-- =====================================================

-- STEP 1: Add product_id column to tbl_purchase_order_dtl
-- =====================================================
ALTER TABLE `tbl_purchase_order_dtl`
ADD COLUMN `product_id` INT(11) NULL AFTER `purchase_header_id`;

-- STEP 2: Populate product_id from existing product_name
-- =====================================================
UPDATE `tbl_purchase_order_dtl` pod
INNER JOIN `tbl_product` p ON p.product_name = pod.product_name
SET pod.product_id = p.product_id
WHERE pod.product_id IS NULL;

-- For products that couldn't be matched, you may want to set them to NULL
-- or handle them separately

-- STEP 3: Add Foreign Key Constraints
-- =====================================================

-- 3.1: Verify/Add FK: Purchase Order Header -> Supplier
-- Check if constraint already exists first, if not add it
SET @fk_supplier_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND CONSTRAINT_NAME = 'fk_po_header_supplier'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_fk_supplier = IF(@fk_supplier_exists = 0,
    'ALTER TABLE `tbl_purchase_order_header` ADD CONSTRAINT `fk_po_header_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `tbl_supplier` (`supplier_id`) ON DELETE RESTRICT ON UPDATE CASCADE',
    'SELECT "Foreign key fk_po_header_supplier already exists" AS message'
);

PREPARE stmt_fk_supplier FROM @sql_fk_supplier;
EXECUTE stmt_fk_supplier;
DEALLOCATE PREPARE stmt_fk_supplier;

-- 3.2: Verify/Add FK: Purchase Order Detail -> Purchase Order Header
SET @fk_header_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_header'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_fk_header = IF(@fk_header_exists = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD CONSTRAINT `fk_po_dtl_header` FOREIGN KEY (`purchase_header_id`) REFERENCES `tbl_purchase_order_header` (`purchase_header_id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT "Foreign key fk_po_dtl_header already exists" AS message'
);

PREPARE stmt_fk_header FROM @sql_fk_header;
EXECUTE stmt_fk_header;
DEALLOCATE PREPARE stmt_fk_header;

-- 3.3: Add FK: Purchase Order Detail -> Product (NEW - this is missing!)
-- Check if constraint already exists first
SET @fk_product_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_product'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_fk_product = IF(@fk_product_exists = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD CONSTRAINT `fk_po_dtl_product` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`product_id`) ON DELETE RESTRICT ON UPDATE CASCADE',
    'SELECT "Foreign key fk_po_dtl_product already exists" AS message'
);

PREPARE stmt_fk_product FROM @sql_fk_product;
EXECUTE stmt_fk_product;
DEALLOCATE PREPARE stmt_fk_product;

-- STEP 4: Add Indexes for Performance (check if exists first)
-- =====================================================
-- Check if idx_po_dtl_product exists, if not add it
SET @idx_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND INDEX_NAME = 'idx_po_dtl_product'
);

SET @sql_idx = IF(@idx_exists = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD INDEX `idx_po_dtl_product` (`product_id`)',
    'SELECT "Index idx_po_dtl_product already exists" AS message'
);

PREPARE stmt_idx FROM @sql_idx;
EXECUTE stmt_idx;
DEALLOCATE PREPARE stmt_idx;

-- STEP 5: Optional - Make product_id NOT NULL for future records
-- =====================================================
-- Only do this after verifying all existing records have product_id populated
-- ALTER TABLE `tbl_purchase_order_dtl` 
-- MODIFY COLUMN `product_id` INT(11) NOT NULL;

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Check foreign keys
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME IN ('tbl_purchase_order_header', 'tbl_purchase_order_dtl')
AND REFERENCED_TABLE_NAME IS NOT NULL;

-- Check for records without product_id (after migration)
SELECT 
    purchase_dtl_id,
    purchase_header_id,
    product_name,
    product_id
FROM tbl_purchase_order_dtl
WHERE product_id IS NULL;

