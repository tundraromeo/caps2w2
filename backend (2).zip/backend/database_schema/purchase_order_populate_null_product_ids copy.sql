-- =====================================================
-- POPULATE NULL product_id VALUES
-- =====================================================
-- I-run ito para mapuno ang mga NULL na product_id
-- Gamit ang existing product_name para mahanap ang tamang product_id
-- =====================================================

-- STEP 1: Check how many records have NULL product_id
SELECT 
    COUNT(*) as total_records,
    SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END) as null_product_id_count,
    SUM(CASE WHEN product_id IS NOT NULL THEN 1 ELSE 0 END) as has_product_id_count
FROM tbl_purchase_order_dtl;

-- STEP 2: Show records with NULL product_id (para macheck mo)
SELECT 
    purchase_dtl_id,
    purchase_header_id,
    product_name,
    product_id,
    quantity
FROM tbl_purchase_order_dtl
WHERE product_id IS NULL
ORDER BY purchase_dtl_id;

-- STEP 3: Populate NULL product_id by matching product_name
UPDATE tbl_purchase_order_dtl pod
INNER JOIN tbl_product p ON p.product_name = pod.product_name
SET pod.product_id = p.product_id
WHERE pod.product_id IS NULL;

-- STEP 4: Check results - should show 0 NULL values after update
SELECT 
    COUNT(*) as total_records,
    SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END) as still_null_count,
    SUM(CASE WHEN product_id IS NOT NULL THEN 1 ELSE 0 END) as populated_count
FROM tbl_purchase_order_dtl;

-- STEP 5: Show records na hindi na-match (kung may ganito)
SELECT 
    purchase_dtl_id,
    product_name,
    'No matching product found in tbl_product' as issue
FROM tbl_purchase_order_dtl
WHERE product_id IS NULL;

-- DONE! ✅

