-- =====================================================
-- SAFE DUPLICATE INDEX REMOVAL
-- =====================================================
-- This only drops manual indexes that duplicate FK indexes
-- It will NOT drop indexes that are used by foreign keys
-- =====================================================

-- For tbl_purchase_order_dtl.purchase_header_id
-- Only drop idx_po_dtl_header if FK uses a DIFFERENT index name (fk_po_dtl_header)

-- Check if FK constraint exists and what index it uses
SET @fk_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_header'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

-- If FK exists and uses 'fk_po_dtl_header' as index, we can safely drop 'idx_po_dtl_header'
-- But if FK uses 'idx_po_dtl_header' as index, we CANNOT drop it
SET @can_drop = (
    SELECT CASE 
        WHEN @fk_exists = 0 THEN 0  -- No FK, check manually
        WHEN EXISTS (
            -- FK uses 'fk_po_dtl_header' as index name
            SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_dtl'
            AND INDEX_NAME = 'fk_po_dtl_header'
            AND COLUMN_NAME = 'purchase_header_id'
        ) AND EXISTS (
            -- Manual index 'idx_po_dtl_header' also exists
            SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_dtl'
            AND INDEX_NAME = 'idx_po_dtl_header'
            AND COLUMN_NAME = 'purchase_header_id'
        ) THEN 1  -- Can drop idx_po_dtl_header (duplicate)
        ELSE 0     -- Cannot drop (FK uses it or doesn't exist)
    END
);

SET @sql_drop = IF(@can_drop = 1,
    'ALTER TABLE `tbl_purchase_order_dtl` DROP INDEX `idx_po_dtl_header`',
    'SELECT "Safe to skip - idx_po_dtl_header is used by FK or not a duplicate" AS message'
);

PREPARE stmt FROM @sql_drop;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Same check for supplier_id
SET @fk_supplier_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND CONSTRAINT_NAME = 'fk_po_header_supplier'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @can_drop_supplier = (
    SELECT CASE 
        WHEN @fk_supplier_exists = 0 THEN 0
        WHEN EXISTS (
            SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_header'
            AND INDEX_NAME = 'fk_po_header_supplier'
            AND COLUMN_NAME = 'supplier_id'
        ) AND EXISTS (
            SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_header'
            AND INDEX_NAME = 'idx_po_supplier'
            AND COLUMN_NAME = 'supplier_id'
        ) THEN 1
        ELSE 0
    END
);

SET @sql_drop_supplier = IF(@can_drop_supplier = 1,
    'ALTER TABLE `tbl_purchase_order_header` DROP INDEX `idx_po_supplier`',
    'SELECT "Safe to skip - idx_po_supplier is used by FK or not a duplicate" AS message'
);

PREPARE stmt_supplier FROM @sql_drop_supplier;
EXECUTE stmt_supplier;
DEALLOCATE PREPARE stmt_supplier;

-- DONE! ✅

