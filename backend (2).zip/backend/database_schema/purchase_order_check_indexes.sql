-- =====================================================
-- CHECK INDEXES BEFORE DROPPING
-- =====================================================
-- Run this FIRST to see which indexes exist and which are used by FKs
-- =====================================================

-- Check indexes on tbl_purchase_order_dtl
SELECT 
    s.INDEX_NAME,
    s.COLUMN_NAME,
    CASE 
        WHEN s.INDEX_NAME IN (
            SELECT CONSTRAINT_NAME 
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_dtl'
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'
        ) THEN '⚠️ FK Index - DO NOT DROP'
        WHEN s.INDEX_NAME = 'PRIMARY' THEN '🔑 Primary Key'
        ELSE '✅ Manual Index - Safe to drop if duplicate'
    END AS INDEX_TYPE,
    CASE 
        WHEN s.COLUMN_NAME = 'purchase_header_id' 
        AND s.INDEX_NAME != 'PRIMARY'
        AND s.INDEX_NAME NOT IN (
            SELECT CONSTRAINT_NAME 
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_dtl'
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'
        )
        AND EXISTS (
            SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS s2
            WHERE s2.TABLE_SCHEMA = DATABASE()
            AND s2.TABLE_NAME = 'tbl_purchase_order_dtl'
            AND s2.COLUMN_NAME = 'purchase_header_id'
            AND s2.INDEX_NAME IN (
                SELECT CONSTRAINT_NAME 
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = 'tbl_purchase_order_dtl'
                AND CONSTRAINT_TYPE = 'FOREIGN KEY'
            )
        ) THEN '🔴 DUPLICATE - Can drop'
        ELSE ''
    END AS DUPLICATE_STATUS
FROM INFORMATION_SCHEMA.STATISTICS s
WHERE s.TABLE_SCHEMA = DATABASE()
AND s.TABLE_NAME = 'tbl_purchase_order_dtl'
ORDER BY s.COLUMN_NAME, s.INDEX_NAME;

-- Check indexes on tbl_purchase_order_header
SELECT 
    s.INDEX_NAME,
    s.COLUMN_NAME,
    CASE 
        WHEN s.INDEX_NAME IN (
            SELECT CONSTRAINT_NAME 
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_header'
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'
        ) THEN '⚠️ FK Index - DO NOT DROP'
        WHEN s.INDEX_NAME = 'PRIMARY' THEN '🔑 Primary Key'
        ELSE '✅ Manual Index - Safe to drop if duplicate'
    END AS INDEX_TYPE
FROM INFORMATION_SCHEMA.STATISTICS s
WHERE s.TABLE_SCHEMA = DATABASE()
AND s.TABLE_NAME = 'tbl_purchase_order_header'
ORDER BY s.COLUMN_NAME, s.INDEX_NAME;

