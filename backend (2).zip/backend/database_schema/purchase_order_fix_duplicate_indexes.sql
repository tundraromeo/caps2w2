-- =====================================================
-- FIX DUPLICATE INDEX WARNINGS
-- =====================================================
-- This script removes duplicate indexes that cause deprecation warnings
-- MySQL/MariaDB automatically creates indexes for FOREIGN KEY constraints
-- Manual indexes on the same columns are duplicates and should be removed
-- =====================================================

-- STEP 1: Remove duplicate index idx_po_dtl_header
-- =====================================================
-- The FK constraint fk_po_dtl_header already creates an index on purchase_header_id
-- If idx_po_dtl_header also exists, it's a duplicate and should be removed

SET @dup_idx_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND INDEX_NAME = 'idx_po_dtl_header'
    AND COLUMN_NAME = 'purchase_header_id'
);

-- If duplicate exists, drop the redundant manual index
-- The FK constraint index (fk_po_dtl_header) is sufficient for performance
SET @sql_drop_dup = IF(@dup_idx_exists > 0,
    'ALTER TABLE `tbl_purchase_order_dtl` DROP INDEX `idx_po_dtl_header`',
    'SELECT "No duplicate index idx_po_dtl_header found - OK" AS message'
);

PREPARE stmt_drop FROM @sql_drop_dup;
EXECUTE stmt_drop;
DEALLOCATE PREPARE stmt_drop;

-- STEP 2: Check for duplicate on supplier_id in header table
-- =====================================================
-- If idx_po_supplier exists and FK fk_po_header_supplier also exists, it's a duplicate
SET @dup_supplier_idx = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND INDEX_NAME = 'idx_po_supplier'
    AND COLUMN_NAME = 'supplier_id'
);

SET @sql_drop_supplier = IF(@dup_supplier_idx > 0,
    'ALTER TABLE `tbl_purchase_order_header` DROP INDEX `idx_po_supplier`',
    'SELECT "No duplicate index idx_po_supplier found - OK" AS message'
);

PREPARE stmt_drop_supplier FROM @sql_drop_supplier;
EXECUTE stmt_drop_supplier;
DEALLOCATE PREPARE stmt_drop_supplier;

-- STEP 2: Check for any other duplicate indexes
-- List all indexes on tbl_purchase_order_dtl to verify
SELECT 
    INDEX_NAME,
    COLUMN_NAME,
    SEQ_IN_INDEX,
    CASE 
        WHEN INDEX_NAME IN (
            SELECT CONSTRAINT_NAME 
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_dtl'
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'
        ) THEN 'FK Index'
        WHEN INDEX_NAME = 'PRIMARY' THEN 'Primary Key'
        ELSE 'Regular Index'
    END AS INDEX_TYPE
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME = 'tbl_purchase_order_dtl'
ORDER BY INDEX_NAME, SEQ_IN_INDEX;

