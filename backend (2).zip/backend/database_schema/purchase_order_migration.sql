-- =====================================================
-- PURCHASE ORDER SYSTEM - Migration Script
-- =====================================================
-- Based on actual database structure from enguio2
-- This script migrates existing tables to add proper foreign keys
-- =====================================================

-- STEP 1: Check if product_id column exists, if not add it
-- =====================================================
-- Note: MariaDB/MySQL doesn't support IF NOT EXISTS for ALTER TABLE COLUMN
-- Run this manually or check first in your SQL client
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND COLUMN_NAME = 'product_id'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD COLUMN `product_id` INT(11) NULL AFTER `purchase_header_id`',
    'SELECT "Column product_id already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- STEP 2: Populate product_id from product_name (if product_id is NULL)
-- =====================================================
-- Update existing records by matching product_name to tbl_product
UPDATE `tbl_purchase_order_dtl` pod
LEFT JOIN `tbl_product` p ON p.product_name = pod.product_name
SET pod.product_id = p.product_id
WHERE pod.product_id IS NULL AND p.product_id IS NOT NULL;

-- STEP 3: Make product_id NOT NULL after populating (if needed)
-- =====================================================
-- Uncomment if you want to enforce NOT NULL constraint
-- ALTER TABLE `tbl_purchase_order_dtl` 
-- MODIFY COLUMN `product_id` INT(11) NOT NULL;

-- STEP 4: Add Foreign Key Constraints (check if exists first)
-- =====================================================

-- 4.1: Add FK: Purchase Order Header -> Supplier (if not exists)
SET @fk_supplier = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_header'
    AND CONSTRAINT_NAME = 'fk_po_header_supplier'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_fk1 = IF(@fk_supplier = 0,
    'ALTER TABLE `tbl_purchase_order_header` ADD CONSTRAINT `fk_po_header_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `tbl_supplier` (`supplier_id`) ON DELETE RESTRICT ON UPDATE CASCADE',
    'SELECT "FK fk_po_header_supplier already exists" AS message'
);

PREPARE stmt_fk1 FROM @sql_fk1;
EXECUTE stmt_fk1;
DEALLOCATE PREPARE stmt_fk1;

-- 4.2: Add FK: Purchase Order Detail -> Purchase Order Header (if not exists)
SET @fk_header = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_header'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_fk2 = IF(@fk_header = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD CONSTRAINT `fk_po_dtl_header` FOREIGN KEY (`purchase_header_id`) REFERENCES `tbl_purchase_order_header` (`purchase_header_id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT "FK fk_po_dtl_header already exists" AS message'
);

PREPARE stmt_fk2 FROM @sql_fk2;
EXECUTE stmt_fk2;
DEALLOCATE PREPARE stmt_fk2;

-- 4.3: Add FK: Purchase Order Detail -> Product (if product_id column exists)
SET @fk_product = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'tbl_purchase_order_dtl'
    AND CONSTRAINT_NAME = 'fk_po_dtl_product'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);

SET @sql_fk3 = IF(@fk_product = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD CONSTRAINT `fk_po_dtl_product` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`product_id`) ON DELETE RESTRICT ON UPDATE CASCADE',
    'SELECT "FK fk_po_dtl_product already exists" AS message'
);

PREPARE stmt_fk3 FROM @sql_fk3;
EXECUTE stmt_fk3;
DEALLOCATE PREPARE stmt_fk3;

-- STEP 5: Add Additional Indexes for Performance (check if exists first)
-- =====================================================
-- Note: MySQL/MariaDB doesn't support IF NOT EXISTS for ALTER TABLE INDEX
-- Using dynamic SQL to check and add only if missing

-- For tbl_purchase_order_header
SET @idx_po_supplier = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'tbl_purchase_order_header' 
    AND INDEX_NAME = 'idx_po_supplier'
);
SET @sql_idx1 = IF(@idx_po_supplier = 0,
    'ALTER TABLE `tbl_purchase_order_header` ADD INDEX `idx_po_supplier` (`supplier_id`)',
    'SELECT "Index idx_po_supplier already exists" AS message'
);
PREPARE stmt_idx1 FROM @sql_idx1;
EXECUTE stmt_idx1;
DEALLOCATE PREPARE stmt_idx1;

SET @idx_po_status = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'tbl_purchase_order_header' 
    AND INDEX_NAME = 'idx_po_status'
);
SET @sql_idx2 = IF(@idx_po_status = 0,
    'ALTER TABLE `tbl_purchase_order_header` ADD INDEX `idx_po_status` (`status`)',
    'SELECT "Index idx_po_status already exists" AS message'
);
PREPARE stmt_idx2 FROM @sql_idx2;
EXECUTE stmt_idx2;
DEALLOCATE PREPARE stmt_idx2;

SET @idx_po_date = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'tbl_purchase_order_header' 
    AND INDEX_NAME = 'idx_po_date'
);
SET @sql_idx3 = IF(@idx_po_date = 0,
    'ALTER TABLE `tbl_purchase_order_header` ADD INDEX `idx_po_date` (`date`)',
    'SELECT "Index idx_po_date already exists" AS message'
);
PREPARE stmt_idx3 FROM @sql_idx3;
EXECUTE stmt_idx3;
DEALLOCATE PREPARE stmt_idx3;

-- For tbl_purchase_order_dtl
-- NOTE: DO NOT create idx_po_dtl_header - the FK constraint fk_po_dtl_header 
-- already creates an index on purchase_header_id automatically!
-- Creating idx_po_dtl_header would be a duplicate and cause deprecation warnings

SET @idx_dtl_product = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'tbl_purchase_order_dtl' 
    AND INDEX_NAME = 'idx_po_dtl_product'
);
SET @sql_idx4 = IF(@idx_dtl_product = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD INDEX `idx_po_dtl_product` (`product_id`)',
    'SELECT "Index idx_po_dtl_product already exists" AS message'
);
PREPARE stmt_idx4 FROM @sql_idx4;
EXECUTE stmt_idx4;
DEALLOCATE PREPARE stmt_idx4;

SET @idx_dtl_status = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'tbl_purchase_order_dtl' 
    AND INDEX_NAME = 'idx_po_dtl_status'
);
SET @sql_idx5 = IF(@idx_dtl_status = 0,
    'ALTER TABLE `tbl_purchase_order_dtl` ADD INDEX `idx_po_dtl_status` (`item_status`)',
    'SELECT "Index idx_po_dtl_status already exists" AS message'
);
PREPARE stmt_idx5 FROM @sql_idx5;
EXECUTE stmt_idx5;
DEALLOCATE PREPARE stmt_idx5;

-- STEP 6: Add Missing Columns (if needed)
-- =====================================================
-- Add unit_price and subtotal if they don't exist
ALTER TABLE `tbl_purchase_order_dtl`
ADD COLUMN IF NOT EXISTS `unit_price` DECIMAL(10, 2) DEFAULT 0.00 AFTER `unit_type`,
ADD COLUMN IF NOT EXISTS `subtotal` DECIMAL(10, 2) DEFAULT 0.00 AFTER `unit_price`;

-- Add timestamps if they don't exist
ALTER TABLE `tbl_purchase_order_header`
ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE `tbl_purchase_order_dtl`
ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

