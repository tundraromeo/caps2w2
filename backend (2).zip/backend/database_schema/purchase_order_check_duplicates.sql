-- =====================================================
-- CHECK FOR DUPLICATE INDEXES
-- =====================================================
-- Run this FIRST to see if there are actually duplicates
-- =====================================================

-- Check indexes on purchase_header_id column
SELECT 
    INDEX_NAME,
    COLUMN_NAME,
    CASE 
        WHEN INDEX_NAME IN (
            SELECT CONSTRAINT_NAME 
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'tbl_purchase_order_dtl'
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'
        ) THEN '⚠️ FK Index - DO NOT DROP!'
        ELSE '✅ Manual Index'
    END AS STATUS
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME = 'tbl_purchase_order_dtl'
AND COLUMN_NAME = 'purchase_header_id'
ORDER BY INDEX_NAME;

-- Analysis:
-- If you see:
-- - Only ONE index (idx_po_dtl_header or fk_po_dtl_header) = NO DUPLICATE ✅
-- - TWO indexes (both idx_po_dtl_header AND fk_po_dtl_header) = DUPLICATE ❌

