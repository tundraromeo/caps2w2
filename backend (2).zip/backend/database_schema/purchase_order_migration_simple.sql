-- =====================================================
-- PURCHASE ORDER MIGRATION - SIMPLE VERSION
-- =====================================================
-- Add product_id column and foreign key relationship
-- Run this script ONCE on your database
-- =====================================================

-- STEP 1: Add product_id column (if not exists)
ALTER TABLE `tbl_purchase_order_dtl`
ADD COLUMN `product_id` INT(11) NULL AFTER `purchase_header_id`;

-- STEP 2: Populate product_id from existing product_name
-- ITO ang nagfi-fill ng NULL values gamit ang product_name
-- I-match ang product_name sa tbl_product para makuha ang product_id
UPDATE `tbl_purchase_order_dtl` pod
INNER JOIN `tbl_product` p ON p.product_name = pod.product_name
SET pod.product_id = p.product_id
WHERE pod.product_id IS NULL;

-- Check kung ilan pa ang NULL after update
SELECT 
    COUNT(*) as total_records,
    SUM(CASE WHEN product_id IS NULL THEN 1 ELSE 0 END) as null_count
FROM tbl_purchase_order_dtl;

-- STEP 3: Add Foreign Key to tbl_product
ALTER TABLE `tbl_purchase_order_dtl`
ADD CONSTRAINT `fk_po_dtl_product` 
    FOREIGN KEY (`product_id`) 
    REFERENCES `tbl_product` (`product_id`)
    ON DELETE RESTRICT 
    ON UPDATE CASCADE;

-- DONE! ✅
-- Now tbl_purchase_order_dtl has product_id and proper FK relationship

