-- ============================================
-- UPDATE DATABASE FOR NEW POS FEATURES
-- ============================================
-- This script adds columns for:
-- 1. Senior Citizen Discount (ID Number & Name)
-- 2. Split Payment (Cash Amount & GCash Amount)
-- ============================================

USE `enguio2`;

-- Add Senior Citizen columns
ALTER TABLE `tbl_pos_sales_header`
ADD COLUMN `senior_id_number` VARCHAR(100) DEFAULT NULL COMMENT 'Senior Citizen ID Number' AFTER `discount_amount`,
ADD COLUMN `senior_name` VARCHAR(255) DEFAULT NULL COMMENT 'Senior Citizen Full Name' AFTER `senior_id_number`;

-- Add Split Payment columns
ALTER TABLE `tbl_pos_sales_header`
ADD COLUMN `cash_amount` DECIMAL(10,2) DEFAULT NULL COMMENT 'Cash portion in split payment' AFTER `reference_number`,
ADD COLUMN `gcash_amount` DECIMAL(10,2) DEFAULT NULL COMMENT 'GCash portion in split payment' AFTER `cash_amount`;

-- Add index for faster senior citizen queries
CREATE INDEX `idx_senior_id` ON `tbl_pos_sales_header` (`senior_id_number`);

-- ============================================
-- VERIFICATION QUERY
-- ============================================
-- Run this to verify the columns were added:
-- DESCRIBE tbl_pos_sales_header;

