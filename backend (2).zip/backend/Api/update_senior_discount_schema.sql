-- ========================================
-- Senior Citizen Discount Schema Update
-- ========================================
-- This script adds fields to capture Senior Citizen ID and Name
-- when Senior discount is applied to POS sales
-- ========================================

-- Add senior_id_number and senior_name columns to tbl_pos_sales_header
ALTER TABLE `tbl_pos_sales_header`
ADD COLUMN `senior_id_number` VARCHAR(100) DEFAULT NULL COMMENT 'Senior Citizen ID Number' AFTER `discount_amount`,
ADD COLUMN `senior_name` VARCHAR(255) DEFAULT NULL COMMENT 'Senior Citizen Full Name' AFTER `senior_id_number`;

-- Add index for faster lookups
CREATE INDEX `idx_senior_id` ON `tbl_pos_sales_header` (`senior_id_number`);

-- ========================================
-- Verification Query
-- ========================================
-- Run this to verify the changes were applied:
-- DESCRIBE tbl_pos_sales_header;
