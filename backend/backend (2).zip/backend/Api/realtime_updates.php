<?php
/**
 * Real-time Updates API using Server-Sent Events (SSE)
 * Provides live updates for inventory changes, returns, transfers, etc.
 */

// CORS headers for SSE
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Cache-Control');

// Handle preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Disable output buffering for real-time streaming
if (ob_get_level()) {
    ob_end_clean();
}

// Use centralized database connection
require_once __DIR__ . '/conn.php';

// Get parameters
$location = $_GET['location'] ?? '';
$location_id = $_GET['location_id'] ?? '';

if (empty($location) || empty($location_id)) {
    echo "data: " . json_encode(['error' => 'Location and location_id are required']) . "\n\n";
    exit();
}

// Function to send SSE data
function sendSSE($data) {
    echo "data: " . json_encode($data) . "\n\n";
    flush();
}

// Function to check for recent changes
function checkForChanges($conn, $location, $location_id) {
    $changes = [];
    
    // Check for recent returns (last 30 seconds)
    $returnStmt = $conn->prepare("
        SELECT 
            pr.return_id,
            pr.location_name,
            pr.status,
            pr.approved_at,
            COUNT(pri.id) as item_count
        FROM tbl_pos_returns pr
        LEFT JOIN tbl_pos_return_items pri ON pr.return_id = pri.return_id
        WHERE pr.location_name LIKE ? 
        AND pr.approved_at >= DATE_SUB(NOW(), INTERVAL 30 SECOND)
        AND pr.status = 'approved'
        GROUP BY pr.return_id
        ORDER BY pr.approved_at DESC
        LIMIT 5
    ");
    $returnStmt->execute(["%$location%"]);
    $recentReturns = $returnStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($recentReturns)) {
        foreach ($recentReturns as $return) {
            $changes[] = [
                'type' => 'return_approved',
                'message' => "Return #{$return['return_id']} approved - {$return['item_count']} items restored",
                'data' => $return,
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
    }
    
    // Check for recent transfers (last 30 seconds)
    $transferStmt = $conn->prepare("
        SELECT 
            th.transfer_header_id,
            th.date,
            th.destination_location_id,
            l.location_name,
            COUNT(td.id) as item_count
        FROM tbl_transfer_header th
        LEFT JOIN tbl_transfer_dtl td ON th.transfer_header_id = td.transfer_header_id
        LEFT JOIN tbl_location l ON th.destination_location_id = l.location_id
        WHERE l.location_name LIKE ?
        AND th.date >= DATE_SUB(NOW(), INTERVAL 30 SECOND)
        AND th.status = 'completed'
        GROUP BY th.transfer_header_id
        ORDER BY th.date DESC
        LIMIT 5
    ");
    $transferStmt->execute(["%$location%"]);
    $recentTransfers = $transferStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($recentTransfers)) {
        foreach ($recentTransfers as $transfer) {
            $changes[] = [
                'type' => 'transfer_completed',
                'message' => "Transfer #{$transfer['transfer_header_id']} completed - {$transfer['item_count']} items transferred",
                'data' => $transfer,
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
    }
    
    // Check for recent POS sales (last 30 seconds)
    $salesStmt = $conn->prepare("
        SELECT 
            psh.sales_header_id,
            psh.transaction_id,
            psh.location_name,
            psh.date_created,
            COUNT(psd.id) as item_count
        FROM tbl_pos_sales_header psh
        LEFT JOIN tbl_pos_sales_dtl psd ON psh.sales_header_id = psd.sales_header_id
        WHERE psh.location_name LIKE ?
        AND psh.date_created >= DATE_SUB(NOW(), INTERVAL 30 SECOND)
        GROUP BY psh.sales_header_id
        ORDER BY psh.date_created DESC
        LIMIT 5
    ");
    $salesStmt->execute(["%$location%"]);
    $recentSales = $salesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($recentSales)) {
        foreach ($recentSales as $sale) {
            $changes[] = [
                'type' => 'inventory_update',
                'message' => "Sale #{$sale['transaction_id']} completed - {$sale['item_count']} items sold",
                'data' => $sale,
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
    }
    
    return $changes;
}

// Send initial connection message
sendSSE([
    'type' => 'connection',
    'message' => "Connected to real-time updates for {$location}",
    'timestamp' => date('Y-m-d H:i:s')
]);

// Keep connection alive and check for changes
$lastCheck = time();
$connectionTime = time();

while (true) {
    // Check if client disconnected
    if (connection_aborted()) {
        break;
    }
    
    // Check for changes every 5 seconds
    if (time() - $lastCheck >= 5) {
        $changes = checkForChanges($conn, $location, $location_id);
        
        foreach ($changes as $change) {
            sendSSE($change);
        }
        
        // Send heartbeat every 30 seconds
        if (time() - $connectionTime >= 30) {
            sendSSE([
                'type' => 'heartbeat',
                'message' => 'Connection alive',
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            $connectionTime = time();
        }
        
        $lastCheck = time();
    }
    
    // Sleep for 1 second to prevent excessive CPU usage
    sleep(1);
}

// Close connection
echo "data: " . json_encode(['type' => 'disconnect', 'message' => 'Connection closed']) . "\n\n";
?>
